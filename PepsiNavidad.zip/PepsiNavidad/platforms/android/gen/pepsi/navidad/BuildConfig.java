/** Automatically generated file. DO NOT MODIFY */
package pepsi.navidad;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}